depositApp.controller('SchemeController',['$scope',function($scope)
{
    $scope.schemeObj={
        schemeName:"",
        tenure:0,
        roi:0.0

    }

    $scope.schemeObj.save=function () {

        console.log($scope.schemeObj.schemeName,"->" ,$scope.schemeObj.tenure,"->",
            $scope.schemeObj.roi);
    }

}])