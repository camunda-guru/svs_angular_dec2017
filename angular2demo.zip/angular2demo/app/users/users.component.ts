import {Component,OnInit,Input} from "@angular/core";
import {UserService} from "../services/userService";

@Component({

    templateUrl:'./app/users/users.component.html',
    styleUrls:['./app/users/users.component.css']
})

export class UserComponent implements OnInit
{


    private users:any=[];
    constructor(private userService:UserService)
    {

    }
    ngOnInit()
    {
        //this.menuItems=["Home","About Us","Financial Services","Insurance","Ecommerce","Enterprise Solutions","Careers"]
        console.log("Invoked....");
        this.userService.getUserInfo().subscribe(response=>{
            this.users.push(response);
            console.log(this.users);
        })
    }

/*
    getService()
    {
        console.log("Invoked....");
        this.userService.getUserInfo().subscribe(response=>{
            this.users.push(response);
            console.log(this.users);
        })

    }
*/
}


