import { NgModule }      from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {CountryComponent} from "./country/country.component";
import {FinanceComponent} from "./finance/finance.component";
import {RegisterComponent} from "./forms/forms.registercomponent";
import {LoginComponent} from "./forms/forms.logincomponent";

const routes: Routes = [
	{
	   path: 'aboutus',
	   component: CountryComponent,
        outlet: 'aboutusOutlet'
	},
    {
        path: 'finservice',
        component: FinanceComponent,
        outlet: 'finOutlet'
    }
    ,
    {
        path: 'register',
        component: RegisterComponent

    }
    ,
    {
        path: 'login',
        component: LoginComponent

    }
];
@NgModule({
  imports: [ 
          RouterModule.forRoot(routes) 
  ],
  exports: [ 
          RouterModule 
  ]
})
export class AppRoutingModule{ } 