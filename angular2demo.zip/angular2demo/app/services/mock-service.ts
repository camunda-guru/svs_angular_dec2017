import {Injectable} from "@angular/core";
import {OPEC} from "../model/opecModel";
import {OPECDATA} from "../model/opecData";

@Injectable()
export class OPECService
{

    getOPECData():Promise<OPEC[]>
    {
       return Promise.resolve(OPECDATA);
    }


}