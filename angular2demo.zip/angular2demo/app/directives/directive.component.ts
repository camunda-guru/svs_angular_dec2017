import{Directive,ElementRef} from "@angular/core";
@Directive({
    selector:'[highlight]'
})
export class HightLightComponent
{
    constructor(private e1:ElementRef)
    {
        if(e1.nativeElement.nodeName==='H1')
        {
             e1.nativeElement.className='h1style';
        }
        if(e1.nativeElement.nodeName==='P')
        {
            e1.nativeElement.nodeName.style.backgroundColor='lightblue';
        }

    }

}