/**
 * Created by BALASUBRAMANIAM on 05-04-2017.
 */
describe('Given we are using a Wanderlust application',function(){
    var scope = {};
    beforeEach(function(){
        module('comments');
        inject(function($controller){
            $controller('CommentController',{$scope:scope});
        });
    });

    it('should define a comments object',function(){
        expect(scope.comments).toBeDefined();
    });


    describe('',function(){

        beforeEach(function(){
            scope.add('Testing Karma');
        });

        it('should add item to last item in comments',function(){
            var lastIndexOfList = scope.comments.length - 1;
            var obj={
                value:"Testing Karma",
                likes:0
            }

            expect(scope.comments[lastIndexOfList]).toEqual(obj);
        });
    });
});