import {Component,OnInit,Input} from "@angular/core";
import {UserService} from "../services/userService";

@Component({
    selector:'menu-list',
    templateUrl:'./app/menu/menu.component.html',
    styleUrls:['./app/menu/menu.component.css']
})

export class MenuComponent implements OnInit
{
    private menuItems:string[];
    @Input() finMessage:string;
    private users:any=[];
    private finData:any=[];
    constructor(private userService:UserService)
    {

    }
    ngOnInit()
    {
        this.menuItems=["Home","About Us","Financial Services","Insurance","Ecommerce","Enterprise Solutions","Careers"]
    }


    getService()
    {
        console.log("Invoked....");
       this.userService.getUserInfo().subscribe(response=>{
             this.users.push(response);
             console.log(this.users);
       })

    }

    getFinService()
    {
        this.users=[];
        this.userService.getOpecData().subscribe(response=>{
            this.finData.push(response);
            console.log(response);
        })
    }


    deactivate()
    {
        this.users=[];
        this.finData=[];
    }

}


