import {Component} from "@angular/core";

@Component({
    selector:'svs-header',
    templateUrl:'./app/app.component.html',
    styleUrls:['./app/app.component.css']

})
export class AppComponent
{
   private logoPath:string="./assets/shriramlogo.jpg";
   private punchLine:string="Result Oriented Approach";

}