import {Component} from "@angular/core";

@Component({
    templateUrl:'./app/forms/forms.logincomponent.html',
    styleUrls:['./app/forms/forms.logincomponent.css']
})
export  class LoginComponent
{

}