/**
 * Created by BALASUBRAMANIAM on 05-04-2017.
 */
angular.module('UserModule',[])
    .controller('DataController',['$scope',function($scope){
        $scope.list = ['test','execute','refactor'];

        $scope.add = function(){
            $scope.list.push('repeat');
        };
    }]);