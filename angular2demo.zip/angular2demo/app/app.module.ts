import {NgModule} from "@angular/core";
import {BrowserModule} from "@angular/platform-browser";
import {CommonModule} from "@angular/common";
import {HttpModule} from "@angular/http";
import {AppComponent} from "./app.component";
import {MenuComponent} from "./menu/menu.component";
import {UserService} from "./services/userService";
import { AppRoutingModule }  from './app-routing.module';
import {UserComponent} from "./users/users.component";
import {CountryComponent} from "./country/country.component";
import {FinanceComponent} from "./finance/finance.component";
import {OPECService} from "./services/mock-service";
import {HightLightComponent} from "./directives/directive.component";
import {CountryNamePipe} from "./filters/filters.component";
import {RegisterComponent} from "./forms/forms.registercomponent";
import {LoginComponent} from "./forms/forms.logincomponent";

@NgModule({
    imports:[BrowserModule,CommonModule,HttpModule,AppRoutingModule],
    declarations:[AppComponent,MenuComponent,HightLightComponent,CountryNamePipe, UserComponent,CountryComponent,FinanceComponent,RegisterComponent,LoginComponent],
    providers:[UserService,OPECService],
    bootstrap:[AppComponent]
})
export class AppModule
{

}