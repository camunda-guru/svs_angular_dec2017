export class Book {
  id: number;
  name: string;
  author: string;
  state: string;
  constructor() {
  }
}