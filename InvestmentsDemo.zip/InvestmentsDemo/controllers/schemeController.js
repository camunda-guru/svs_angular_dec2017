depositApp.controller('SchemeController',['$scope',function($scope)
{
    $scope.schemeObj={
        schemeName:"DPSE",
        tenure:2,
        roi:7.5

    }

}])