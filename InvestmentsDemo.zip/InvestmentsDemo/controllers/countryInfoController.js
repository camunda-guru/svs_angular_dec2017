depositApp.controller('CountryInfoController',['$scope',
    'CountryDataService',function($scope,CountryDataService)
{

    CountryDataService.CountryDataServiceObj().then(function(response)
    {
        //console.log(response.data);
        $scope.countryData=response.data;
    })

}])