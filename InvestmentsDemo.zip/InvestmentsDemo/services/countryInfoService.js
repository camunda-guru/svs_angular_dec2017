depositApp.service('CountryDataService',['$http',function($http)
{

    var countryList=function()
    {
        return $http({
            method: 'GET',
            dataType: "jsonp",
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            url: 'https://restcountries.eu/rest/v2/all'

        }).then((function (info) {
            console.log("resolved");
            return info;
        }));
    }
    //closures
    return{

        CountryDataServiceObj:countryList
    };




}])